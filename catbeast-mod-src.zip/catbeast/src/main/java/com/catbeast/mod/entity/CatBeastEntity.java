package com.catbeast.mod.entity;

import com.catbeast.mod.entity.ai.CatBeastAmbushGoal;
import com.catbeast.mod.entity.ai.CatBeastHuntGoal;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.UUID;

/**
 * Core entity for all three cat beast species. One class drives Lion, Jaguar
 * and Leopard; behaviour differs by CatBeastVariant and by the synced data
 * below (tamed, owner, bond, hunger, hunting mode, ability cooldown).
 *
 * Riding: once bond >= RIDE_BOND_THRESHOLD, the owner can mount by sneak +
 * right click. Controlled like a horse (WASD + jump), speed scaled by
 * variant and current hunger/bond level.
 *
 * Care: hunger drains slowly over time. Feeding raw meat restores hunger and
 * raises bond. If hunger hits 0, the beast becomes "neglected": lower damage,
 * lower speed, and it will eventually stop obeying commands (still tamed,
 * but ignores sit/follow/hunting-mode toggles) until fed again.
 *
 * Hunting mode: toggled by the owner (sneak + right click empty-handed while
 * not mounting). In hunting mode the beast roams independently, actively
 * hunts nearby prey/hostile mobs instead of following, and gets a speed
 * bonus. Toggling off returns it to normal companion behaviour.
 */
public class CatBeastEntity extends TamableAnimal {

    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(CatBeastEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> BOND =
            SynchedEntityData.defineId(CatBeastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HUNGER =
            SynchedEntityData.defineId(CatBeastEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> HUNTING_MODE =
            SynchedEntityData.defineId(CatBeastEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> ABILITY_COOLDOWN =
            SynchedEntityData.defineId(CatBeastEntity.class, EntityDataSerializers.INT);

    public static final float MAX_BOND = 100.0F;
    public static final float MAX_HUNGER = 100.0F;
    public static final float RIDE_BOND_THRESHOLD = 40.0F;
    public static final float NEGLECT_THRESHOLD = 15.0F;

    private int hungerTickCounter;
    private int lastPounceTick;

    public CatBeastEntity(EntityType<? extends CatBeastEntity> type, Level level) {
        super(type, level);
        this.setTame(false, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ARMOR, 2.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0);
        builder.define(BOND, 20.0F);
        builder.define(HUNGER, 80.0F);
        builder.define(HUNTING_MODE, false);
        builder.define(ABILITY_COOLDOWN, 0);
    }

    // ---------- variant / stat wiring ----------

    public CatBeastVariant getVariant() {
        return CatBeastVariant.byId(this.entityData.get(VARIANT));
    }

    public void setVariant(CatBeastVariant variant) {
        this.entityData.set(VARIANT, variant.getId());
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(variant.maxHealth);
        this.setHealth((float) variant.maxHealth);
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(variant.movementSpeed);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(variant.attackDamage);
    }

    // ---------- care system ----------

    public float getBond() {
        return this.entityData.get(BOND);
    }

    public void addBond(float amount) {
        this.entityData.set(BOND, Mth_clamp(getBond() + amount, 0.0F, MAX_BOND));
    }

    public float getHunger() {
        return this.entityData.get(HUNGER);
    }

    public void addHunger(float amount) {
        this.entityData.set(HUNGER, Mth_clamp(getHunger() + amount, 0.0F, MAX_HUNGER));
    }

    public boolean isNeglected() {
        return getHunger() <= NEGLECT_THRESHOLD;
    }

    private static float Mth_clamp(float v, float min, float max) {
        return v < min ? min : (v > max ? max : v);
    }

    // ---------- hunting mode ----------

    public boolean isHuntingMode() {
        return this.entityData.get(HUNTING_MODE);
    }

    public void setHuntingMode(boolean value) {
        this.entityData.set(HUNTING_MODE, value);
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.ANGRY_VILLAGER, getX(), getY() + getBbHeight(), getZ(), 6, 0.3, 0.3, 0.3, 0.01);
        }
    }

    // ---------- ability cooldown ----------

    public int getAbilityCooldown() {
        return this.entityData.get(ABILITY_COOLDOWN);
    }

    public void setAbilityCooldown(int ticks) {
        this.entityData.set(ABILITY_COOLDOWN, ticks);
    }

    @Override
    public void tick() {
        super.tick();

        if (getAbilityCooldown() > 0) {
            setAbilityCooldown(getAbilityCooldown() - 1);
        }

        // Hunger drains slowly; faster while sprinting/hunting/riding.
        if (!this.level().isClientSide) {
            hungerTickCounter++;
            int drainInterval = isHuntingMode() ? 200 : 400; // every 10s or 20s
            if (hungerTickCounter >= drainInterval) {
                hungerTickCounter = 0;
                addHunger(-1.0F);
            }

            // Neglected beasts are weaker and slower.
            double baseSpeed = getVariant().movementSpeed;
            double speedMod = isNeglected() ? baseSpeed * 0.6 : baseSpeed;
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speedMod);
        }
    }

    @Override
    public float getSpeed() {
        float speed = super.getSpeed();
        return isNeglected() ? speed * 0.7F : speed;
    }

    // ---------- AI goals ----------

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new CatBeastAmbushGoal(this)); // leopard stealth pounce, no-op for others
        this.goalSelector.addGoal(4, new MeleeAttackGoal(this, 1.3D, true));
        this.goalSelector.addGoal(5, new CatBeastHuntGoal(this)); // active hunting-mode targeting/roaming
        this.goalSelector.addGoal(6, new FollowOwnerGoal(this, 1.0D, 10.0F, 2.0F, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this).setAlertOthers());
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class, 10, false, false,
                e -> !isTame() || isHuntingMode()));
    }

    // ---------- taming, feeding, riding, mode toggle ----------

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Feeding: raw meats restore hunger; if untamed, has a chance to tame.
        if (isFood(stack)) {
            if (!this.level().isClientSide) {
                if (!isTame()) {
                    stack.shrink(1);
                    if (this.random.nextInt(3) == 0) {
                        tame(player);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                        addBond(2.0F);
                    }
                    return InteractionResult.SUCCESS;
                } else {
                    stack.shrink(1);
                    addHunger(20.0F);
                    addBond(isOwnedBy(player) ? 3.0F : 0.5F);
                    this.level().playSound(null, this, SoundEvents.CAT_PURR, SoundSource.NEUTRAL, 0.6F, 1.0F);
                    return InteractionResult.SUCCESS;
                }
            }
            return InteractionResult.CONSUME;
        }

        if (isTame() && isOwnedBy(player)) {
            // Sneak + empty hand: toggle hunting mode.
            if (player.isShiftKeyDown() && stack.isEmpty()) {
                if (!this.level().isClientSide) {
                    setHuntingMode(!isHuntingMode());
                    this.setOrderedToSit(false);
                    player.displayClientMessage(net.minecraft.network.chat.Component.translatable(
                            isHuntingMode() ? "catbeast.mode.hunting_on" : "catbeast.mode.hunting_off",
                            this.getDisplayName()), true);
                }
                return InteractionResult.SUCCESS;
            }

            // Empty hand, not sneaking: mount if bonded enough, else sit toggle.
            if (stack.isEmpty() && !isNeglected()) {
                if (getBond() >= RIDE_BOND_THRESHOLD) {
                    if (!this.level().isClientSide) {
                        player.startRiding(this);
                    }
                    return InteractionResult.SUCCESS;
                } else {
                    this.setOrderedToSit(!this.isOrderedToSit());
                    return InteractionResult.SUCCESS;
                }
            }
        }

        return super.mobInteract(player, hand);
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        return null; // breeding intentionally out of scope for v1
    }

    // ---------- riding control ----------

    @Override
    public boolean isControlledByRider() {
        return this.getFirstPassenger() instanceof Player;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return this.getFirstPassenger() instanceof Player p ? p : null;
    }

    @Override
    protected void tickRidden(Player player, Vec3 travelVector) {
        super.tickRidden(player, travelVector);
        this.setYRot(player.getYRot());
        this.yRotO = this.getYRot();
        this.setXRot(player.getXRot() * 0.5F);
        this.setRot(this.getYRot(), this.getXRot());
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.yBodyRot;
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 input) {
        float forward = player.zza;
        float strafe = player.xxa;
        if (forward <= 0.0F) forward *= 0.25F;
        return new Vec3(strafe, 0.0D, forward);
    }

    @Override
    protected float getRiddenSpeed(Player player) {
        double base = getVariant().movementSpeed * getVariant().sprintMultiplier;
        double speed = isNeglected() ? base * 0.6 : base;
        return (float) speed;
    }

    // ---------- combat ----------

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        boolean success = super.doHurtTarget(target);
        if (success && target instanceof LivingEntity living) {
            switch (getVariant()) {
                case JAGUAR -> {
                    // Bone-crush bite passive: small chance of bonus true-ish damage via extra hit.
                    if (this.random.nextFloat() < 0.15F) {
                        living.hurt(this.damageSources().mobAttack(this), 3.0F);
                    }
                }
                case LEOPARD -> {
                    // Ambush bonus already applied by CatBeastAmbushGoal via setAbilityCooldown trigger.
                }
                case LION -> {
                    // Lions occasionally roar on hit to intimidate nearby hostiles.
                    if (this.random.nextFloat() < 0.1F) {
                        useSpecialAbility();
                    }
                }
            }
        }
        return success;
    }

    /**
     * Owner-triggered special ability. Wire this to a keybind/packet on the
     * client (e.g. pressing a "Beast Ability" key while riding or nearby).
     */
    public boolean useSpecialAbility() {
        if (getAbilityCooldown() > 0) return false;

        switch (getVariant()) {
            case LION -> {
                // Roar of Dominance: AoE weaken + fear nearby hostile mobs.
                this.level().playSound(null, this, SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 1.5F, 0.8F);
                for (LivingEntity nearby : this.level().getEntitiesOfClass(LivingEntity.class,
                        this.getBoundingBox().inflate(8.0D), e -> e instanceof Monster)) {
                    nearby.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                    Vec3 away = nearby.position().subtract(this.position()).normalize().scale(0.6D);
                    nearby.push(away.x, 0.1D, away.z);
                }
                setAbilityCooldown(600); // 30s
            }
            case JAGUAR -> {
                // Bone-Crush Bite: guaranteed heavy hit + armor-ignoring damage on current target.
                if (this.getTarget() != null) {
                    LivingEntity target = this.getTarget();
                    this.level().playSound(null, this, SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 1.2F, 0.7F);
                    target.hurt(this.damageSources().mobAttack(this), getVariant().attackDamage * 1.8F);
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
                }
                setAbilityCooldown(400); // 20s
            }
            case LEOPARD -> {
                // Ambush Pounce: burst of speed toward target + bonus damage, from CatBeastAmbushGoal stealth.
                if (this.getTarget() != null) {
                    LivingEntity target = this.getTarget();
                    Vec3 toTarget = target.position().subtract(this.position()).normalize().scale(1.6D);
                    this.setDeltaMovement(toTarget.x, 0.4D, toTarget.z);
                    this.level().playSound(null, this, SoundEvents.FOX_AGGRO, SoundSource.HOSTILE, 1.0F, 1.3F);
                }
                setAbilityCooldown(300); // 15s
            }
        }
        return true;
    }

    @Override
    public boolean canBeLeashed() {
        return true;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(ItemTags.MEAT) || stack.is(Items.BEEF) || stack.is(Items.PORKCHOP)
                || stack.is(Items.CHICKEN) || stack.is(Items.RABBIT) || stack.is(Items.MUTTON);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant().getId());
        tag.putFloat("Bond", getBond());
        tag.putFloat("Hunger", getHunger());
        tag.putBoolean("HuntingMode", isHuntingMode());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(CatBeastVariant.byId(tag.getInt("Variant")));
        this.entityData.set(BOND, tag.getFloat("Bond"));
        this.entityData.set(HUNGER, tag.getFloat("Hunger"));
        this.entityData.set(HUNTING_MODE, tag.getBoolean("HuntingMode"));
    }
}
