# Cat Beasts — NeoForge 1.21.1 mod

Tameable, rideable big cats: **Lion**, **Jaguar**, **Leopard** — one entity
class (`CatBeastEntity`), three variants (`CatBeastVariant`), each with a
unique special ability, a hunting mode, and a real hunger/bond care system.

## What's implemented (source-complete, needs assets + build)

- **Taming**: feed raw meat (beef/porkchop/chicken/rabbit/mutton) to an
  untamed cat beast; chance to tame per feed, always raises bond.
- **Riding**: once bond ≥ 40, empty-hand right-click mounts it (below that,
  right-click toggles sit/stand instead). Controlled like a horse; speed is
  variant-based and drops if the beast is neglected.
- **Combat**:
  - Lion — high HP/damage tank, occasional roar-on-hit.
  - Jaguar — highest raw damage, 15% chance of a bonus bite on each hit.
  - Leopard — fastest, stealth-stalks a target (camouflage via brief
    Invisibility while still) then bursts into a bonus-damage pounce.
- **Special abilities** (`CatBeastEntity#useSpecialAbility()`, on a
  15–30s cooldown depending on variant — wire this to a keybind packet):
  - Lion: **Roar of Dominance** — AoE weaken + knockback on nearby hostiles.
  - Jaguar: **Bone-Crush Bite** — guaranteed heavy hit + slows the target.
  - Leopard: **Ambush Pounce** — speed burst + bonus strike on current target.
- **Hunting mode**: sneak + empty-hand right-click toggles it. While on, the
  beast ignores owner-following and actively hunts nearby prey/hostiles
  (`CatBeastHuntGoal`). Toggle again to return to companion behaviour.
- **Care system**: hunger (0–100) drains slowly over time (faster while
  hunting), restored by feeding. Below 15 hunger the beast is "neglected" —
  reduced speed and damage until fed again. Bond (0–100) rises from feeding
  and gates riding.

## What you still need to add before this compiles & runs

1. **Client rendering**: a `CatBeastRenderer` + `EntityModelLayer` + actual
   3D model (Blockbench → Java, or a mod like GeckoLib for animation) and
   textures for each variant. `src/main/java/com/catbeast/mod/client/` is
   scaffolded but empty — this is the single biggest remaining chunk of work,
   since it needs real art assets I can't generate here.
2. **Special-ability input**: hook a keybind (client) → network packet
   (`PayloadHandler`) → `CatBeastEntity#useSpecialAbility()` on the server.
   Right now the ability only fires automatically in a couple of spots
   (e.g. leopard ambush, occasional lion roar) — you'll want a deliberate
   player-triggered version too.
3. **Loot table / spawn egg model/texture** for `cat_beast_spawn_egg`.
4. **Biome spawn placement** — currently registered but not added to any
   biome's spawn list; add a `NeoForgeBiomeModifiers` JSON datapack entry
   (savanna for lion, jungle for jaguar/leopard makes thematic sense).
5. A `gradle/wrapper` — the CI workflow (`.github/workflows/build.yml`)
   generates one automatically if it's missing, so you don't need Gradle
   installed on your phone; just push to `main` and download the built jar
   from the Actions run's artifacts.

## Project layout

```
src/main/java/com/catbeast/mod/
  CatBeastMod.java            – mod entrypoint, registers everything
  entity/CatBeastEntity.java  – the whole creature: taming/riding/combat/care
  entity/CatBeastVariant.java – Lion/Jaguar/Leopard stat table
  entity/ModEntities.java     – entity type registry
  entity/ai/CatBeastHuntGoal.java    – hunting-mode roam/target AI
  entity/ai/CatBeastAmbushGoal.java  – leopard stealth-pounce AI
  item/ModItems.java          – spawn egg
```

## Building

Push to `main` (or run the workflow manually) and GitHub Actions will
build the mod and attach the jar as a downloadable artifact — no PC needed.
