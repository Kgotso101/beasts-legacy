package com.catbeast.mod.entity.ai;

import com.catbeast.mod.entity.CatBeastEntity;
import com.catbeast.mod.entity.CatBeastVariant;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Leopard-only stealth-and-pounce behaviour. While the leopard has a target
 * but is not yet within striking range and hasn't moved recently, it goes
 * translucent (Invisibility) to simulate camouflage/crouch-stalking, then
 * bursts into a leap attack with bonus damage once close. No-op for other
 * variants.
 */
public class CatBeastAmbushGoal extends Goal {

    private final CatBeastEntity beast;
    private int stalkTicks;
    private boolean pounced;

    public CatBeastAmbushGoal(CatBeastEntity beast) {
        this.beast = beast;
        this.setFlags(EnumSet.of(Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return beast.getVariant() == CatBeastVariant.LEOPARD
                && beast.getTarget() != null
                && beast.getTarget().isAlive()
                && !beast.isVehicle();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        stalkTicks = 0;
        pounced = false;
    }

    @Override
    public void tick() {
        LivingEntity target = beast.getTarget();
        if (target == null) return;

        double distSqr = beast.distanceToSqr(target);

        if (distSqr > 16.0D && distSqr < 100.0D) {
            // Stalking range: build camouflage.
            stalkTicks++;
            if (stalkTicks > 20 && beast.getDeltaMovement().horizontalDistanceSqr() < 0.002D) {
                beast.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 30, 0, true, false));
            }
        } else {
            stalkTicks = 0;
        }

        // Close range burst: consume the ambush bonus once per approach.
        if (!pounced && distSqr <= 9.0D && beast.getAbilityCooldown() == 0) {
            pounced = true;
            Vec3 toTarget = target.position().subtract(beast.position()).normalize().scale(1.3D);
            beast.setDeltaMovement(toTarget.x, 0.35D, toTarget.z);
            target.hurt(beast.damageSources().mobAttack(beast), beast.getVariant().attackDamage * 1.4F);
            beast.setAbilityCooldown(150); // short reset so it can ambush again soon after repositioning
        }

        if (distSqr > 100.0D) {
            pounced = false;
        }
    }

    @Override
    public void stop() {
        stalkTicks = 0;
        pounced = false;
    }
}
