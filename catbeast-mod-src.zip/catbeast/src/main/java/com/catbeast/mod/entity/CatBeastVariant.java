package com.catbeast.mod.entity;

/**
 * The three cat beast species. Each has different base stats and a unique
 * special ability used via CatBeastEntity#useSpecialAbility().
 */
public enum CatBeastVariant {
    LION(0, "lion", 14.0D, 0.32D, 26.0F, 1.15D),
    JAGUAR(1, "jaguar", 11.0D, 0.36D, 22.0F, 1.35D),
    LEOPARD(2, "leopard", 9.0D, 0.40D, 20.0F, 1.45D);

    private final int id;
    private final String key;
    public final double maxHealth;
    public final double movementSpeed;
    public final float attackDamage;
    public final double sprintMultiplier;

    CatBeastVariant(int id, String key, double maxHealth, double movementSpeed, float attackDamage, double sprintMultiplier) {
        this.id = id;
        this.key = key;
        this.maxHealth = maxHealth;
        this.movementSpeed = movementSpeed;
        this.attackDamage = attackDamage;
        this.sprintMultiplier = sprintMultiplier;
    }

    public int getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public static CatBeastVariant byId(int id) {
        for (CatBeastVariant v : values()) {
            if (v.id == id) return v;
        }
        return LION;
    }
}
