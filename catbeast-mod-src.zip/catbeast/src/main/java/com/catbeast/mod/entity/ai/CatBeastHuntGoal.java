package com.catbeast.mod.entity.ai;

import com.catbeast.mod.entity.CatBeastEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Rabbit;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.monster.Monster;

import java.util.EnumSet;
import java.util.List;

/**
 * Drives independent "hunting mode" behaviour: while active, the beast
 * ignores its owner-follow leash range, actively scans for nearby prey
 * animals and hostiles, and chases them down. While inactive this goal
 * does nothing (normal companion goals take over).
 */
public class CatBeastHuntGoal extends Goal {

    private final CatBeastEntity beast;
    private LivingEntity huntTarget;
    private int scanCooldown;

    public CatBeastHuntGoal(CatBeastEntity beast) {
        this.beast = beast;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.TARGET));
    }

    @Override
    public boolean canUse() {
        if (!beast.isHuntingMode() || beast.isNeglected() || beast.isVehicle()) {
            return false;
        }
        if (scanCooldown-- > 0) {
            return beast.getTarget() != null;
        }
        scanCooldown = 20;

        List<Animal> prey = beast.level().getEntitiesOfClass(Animal.class,
                beast.getBoundingBox().inflate(16.0D),
                a -> (a instanceof Rabbit || a instanceof Sheep || a instanceof Chicken || a instanceof Pig)
                        && a.isAlive());
        if (!prey.isEmpty()) {
            huntTarget = prey.get(beast.getRandom().nextInt(prey.size()));
            return true;
        }

        List<Monster> hostiles = beast.level().getEntitiesOfClass(Monster.class,
                beast.getBoundingBox().inflate(16.0D), Monster::isAlive);
        if (!hostiles.isEmpty()) {
            huntTarget = hostiles.get(beast.getRandom().nextInt(hostiles.size()));
            return true;
        }
        return false;
    }

    @Override
    public boolean canContinueToUse() {
        return beast.isHuntingMode() && huntTarget != null && huntTarget.isAlive()
                && beast.distanceToSqr(huntTarget) < 400.0D;
    }

    @Override
    public void start() {
        beast.setTarget(huntTarget);
    }

    @Override
    public void tick() {
        if (huntTarget == null) return;
        beast.getNavigation().moveTo(huntTarget, getSpeedModifier());
        beast.getLookControl().setLookAt(huntTarget, 30.0F, 30.0F);
    }

    private double getSpeedModifier() {
        return 1.3D;
    }

    @Override
    public void stop() {
        huntTarget = null;
        if (beast.getTarget() != null && !beast.getTarget().isAlive()) {
            beast.setTarget(null);
        }
    }
}
