package com.catbeast.mod.item;

import com.catbeast.mod.entity.ModEntities;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, "catbeast");

    public static final DeferredHolder<Item, SpawnEggItem> CAT_BEAST_SPAWN_EGG =
            ITEMS.register("cat_beast_spawn_egg", () -> new SpawnEggItem(
                    ModEntities.CAT_BEAST.get(), 0xC2A05A, 0x3B2A1A,
                    new Item.Properties()));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
