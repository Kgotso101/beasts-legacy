package com.catbeast.mod;

import com.catbeast.mod.entity.CatBeastEntity;
import com.catbeast.mod.entity.ModEntities;
import com.catbeast.mod.item.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(CatBeastMod.MOD_ID)
public class CatBeastMod {
    public static final String MOD_ID = "catbeast";

    public CatBeastMod(IEventBus modBus) {
        ModEntities.register(modBus);
        ModItems.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::registerAttributes);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> SpawnPlacements.register(
                ModEntities.CAT_BEAST.get(),
                SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                CatBeastEntity::checkAnimalSpawnRules));
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CAT_BEAST.get(), CatBeastEntity.createAttributes().build());
    }
}
