package com.catbeast.mod.entity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, "catbeast");

    public static final DeferredHolder<EntityType<?>, EntityType<CatBeastEntity>> CAT_BEAST =
            ENTITY_TYPES.register("cat_beast", () -> EntityType.Builder.of(CatBeastEntity::new, MobCategory.CREATURE)
                    .sized(1.3F, 1.2F)
                    .clientTrackingRange(10)
                    .build("cat_beast"));

    public static void register(IEventBus bus) {
        ENTITY_TYPES.register(bus);
    }
}
